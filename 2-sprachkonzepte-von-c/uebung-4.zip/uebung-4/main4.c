/*#include <stdio.h>

typedef struct {
    char name[32];
    int alter;
} Person;

void printPersonPointer(Person *p);

int main4(void) {
    Person max = {"Max", 18};
    printPersonPointer(&max);
    return 0;
}

void printPersonPointer(Person *p) {
    printf("%s, %d\n", p->name, p->alter);
}*/