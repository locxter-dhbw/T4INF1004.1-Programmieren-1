/*#include <stdio.h>

typedef struct {
    char name[32];
    int alter;
} Person;

int main2(void) {
    Person max = {"Max", 18};
    Person* pMax = &max;
    printf("%s, %d\n", pMax->name, pMax->alter);
    return 0;
}*/