/*#include <stdio.h>

typedef struct {
    char stadt[32];
    int plz;
} Adresse;

typedef struct {
    char name[32];
    int alter;
    Adresse adresse;
} Person;

int main6(void) {
    printf("Hello, World!\n");
    return 0;
}*/