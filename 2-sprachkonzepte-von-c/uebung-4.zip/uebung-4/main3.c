/*#include <stdio.h>

typedef struct {
    char name[32];
    int alter;
} Person;

void printPerson(Person p);

int main3(void) {
    Person max = {"Max", 18};
    printPerson(max);
    return 0;
}

void printPerson(Person p) {
    printf("%s, %d\n", p.name, p.alter);
}*/